# Carpeta data

No es necesario subir manualmente la base de datos si se descarga desde la fuente oficial.

El script `avance_body_dimensions.R` descarga los datos desde:

https://www.openintro.org/data/csv/bdims.csv

Si la descarga falla, descargar manualmente el archivo `bdims.csv` desde OpenIntro y guardarlo en esta carpeta con el nombre:

`bdims.csv`
