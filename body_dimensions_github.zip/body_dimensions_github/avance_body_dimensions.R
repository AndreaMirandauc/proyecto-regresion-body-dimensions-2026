############################################################
# Proyecto EYP2307 - Avance Body Dimensions
# Objetivo: preparar EDA, modelos iniciales y salidas para GitHub
# Este script usa código simple y reproducible.
############################################################

# 1) Crear carpetas si no existen ---------------------------------------
if (!dir.exists("data")) dir.create("data")
if (!dir.exists("figures")) dir.create("figures")
if (!dir.exists("output")) dir.create("output")

# 2) Descargar o leer datos ---------------------------------------------
url_datos <- "https://www.openintro.org/data/csv/bdims.csv"
ruta_datos <- "data/bdims.csv"

if (!file.exists(ruta_datos)) {
  download.file(url_datos, destfile = ruta_datos, mode = "wb")
}

datos <- read.csv(ruta_datos)

# 3) Revisión inicial ----------------------------------------------------
cat("Dimensiones de la base:\n")
print(dim(datos))

cat("Nombres de variables:\n")
print(names(datos))

# Codificar sexo de forma entendible
# En esta base: 1 = hombre, 0 = mujer.
datos$sex_f <- factor(datos$sex,
                      levels = c(0, 1),
                      labels = c("Mujer", "Hombre"))

# Faltantes por variable
faltantes <- data.frame(
  variable = names(datos),
  n_faltantes = colSums(is.na(datos))
)
write.csv(faltantes, "output/faltantes_por_variable.csv", row.names = FALSE)

# Resumen de variables principales
vars_principales <- c("wgt", "hgt", "age", "wai.gi", "hip.gi", "che.gi")
resumen <- summary(datos[vars_principales])
capture.output(resumen, file = "output/resumen_variables_principales.txt")

# 4) Gráficos exploratorios ---------------------------------------------

# Figura 1: peso vs estatura
png("figures/fig01_peso_estatura.png", width = 900, height = 650)
plot(datos$hgt, datos$wgt,
     xlab = "Estatura (cm)",
     ylab = "Peso (kg)",
     main = "Peso versus estatura",
     pch = 19,
     col = ifelse(datos$sex_f == "Hombre", "steelblue", "tomato"))
abline(lm(wgt ~ hgt, data = datos), lwd = 2)
legend("topleft", legend = c("Hombre", "Mujer"),
       col = c("steelblue", "tomato"), pch = 19, bty = "n")
dev.off()

# Figura 2: peso vs cintura
png("figures/fig02_peso_cintura.png", width = 900, height = 650)
plot(datos$wai.gi, datos$wgt,
     xlab = "Perímetro de cintura (cm)",
     ylab = "Peso (kg)",
     main = "Peso versus perímetro de cintura",
     pch = 19,
     col = ifelse(datos$sex_f == "Hombre", "steelblue", "tomato"))
abline(lm(wgt ~ wai.gi, data = datos), lwd = 2)
legend("topleft", legend = c("Hombre", "Mujer"),
       col = c("steelblue", "tomato"), pch = 19, bty = "n")
dev.off()

# Figura 3: boxplot peso por sexo
png("figures/fig03_peso_por_sexo.png", width = 900, height = 650)
boxplot(wgt ~ sex_f, data = datos,
        xlab = "Sexo",
        ylab = "Peso (kg)",
        main = "Distribución del peso según sexo")
dev.off()

# Figura 4: matriz de pares simple
png("figures/fig04_pares_variables.png", width = 900, height = 900)
pairs(datos[vars_principales],
      main = "Relaciones entre variables principales",
      pch = 19,
      cex = 0.5)
dev.off()

# 5) Modelos candidatos --------------------------------------------------

m0 <- lm(wgt ~ hgt, data = datos)
m1 <- lm(wgt ~ hgt + age + sex_f, data = datos)
m2 <- lm(wgt ~ hgt + sex_f + wai.gi + hip.gi + che.gi, data = datos)
m3 <- lm(wgt ~ hgt + sex_f + wai.gi * sex_f + hip.gi + che.gi, data = datos)

capture.output(summary(m0), file = "output/modelo_m0_summary.txt")
capture.output(summary(m1), file = "output/modelo_m1_summary.txt")
capture.output(summary(m2), file = "output/modelo_m2_summary.txt")
capture.output(summary(m3), file = "output/modelo_m3_summary.txt")

capture.output(anova(m0, m1, m2, m3), file = "output/comparacion_modelos_anidados.txt")

# 6) Diagnósticos preliminares del modelo M2 -----------------------------

png("figures/fig05_diagnosticos_m2.png", width = 1000, height = 900)
par(mfrow = c(2, 2))
plot(m2)
par(mfrow = c(1, 1))
dev.off()

# Distancia de Cook
cook <- cooks.distance(m2)
casos_cook <- data.frame(
  observacion = seq_along(cook),
  cook = cook
)
casos_cook <- casos_cook[order(-casos_cook$cook), ]
write.csv(head(casos_cook, 20), "output/top20_distancia_cook_m2.csv", row.names = FALSE)

# VIF opcional, si está instalado el paquete car
if (requireNamespace("car", quietly = TRUE)) {
  vif_m2 <- car::vif(m2)
  capture.output(vif_m2, file = "output/vif_m2.txt")
} else {
  cat("Paquete car no instalado. Para VIF usar install.packages('car').\n",
      file = "output/vif_m2.txt")
}

# 7) Guardar información de sesión --------------------------------------
capture.output(sessionInfo(), file = "output/sessionInfo.txt")

cat("Script terminado. Revisa las carpetas figures/ y output/.\n")
